import pygame
import random
#from pygame.locals import * 
import sys


class FlappyBird:
    def __init__(self):

        # define screen size
        self.screen = pygame.display.set_mode((400, 708))
        
        # initial location and size of bird
        self.bird = pygame.Rect(65, 50, 50, 50)
        
        #load images from file and convert
#        self.background = pygame.image.load("I/bg.png").convert()
#        self.birdSprites = [pygame.image.load("imgs/bird.2.png").convert_alpha(),
#                            pygame.image.load("imgs/bird.3.png").convert_alpha(),
#                            pygame.image.load("I/dead.png")]
#        self.wallUp = pygame.image.load("I/bottom.png").convert_alpha()
#        self.wallDown = pygame.image.load("I/top.png").convert_alpha()
        
#        # background image
#        self.background = pygame.image.load("arctic.imgs/bg.png").convert()
        # bird annimation (still image, flapping image, dead image)
#        self.birdSprites = [pygame.image.load("arctic.imgs/bird.2.png").convert_alpha(),
#                            pygame.image.load("arctic.imgs/bird.3.png").convert_alpha(),
#                            pygame.image.load("arctic.imgs/dead.png")]
        # bottom pipe                  
#        self.wallUp = pygame.image.load("arctic.imgs/bottom.png").convert_alpha()
        # top pipe
#        self.wallDown = pygame.image.load("arctic.imgs/top.png").convert_alpha()
        # message box
#        self.msgbox = pygame.image.load("arctic.imgs/msgbox.png").convert_alpha()

    #Call on change theme to 
        self.changeTheme(random.randint(1,3))

        # initial X location of pipe 
        self.pipe = 400
        # distance between pipes
        self.distance = 200   
        # Y-axis of bird position
        self.birdY = 300
        # 
        self.jump = 0
        # how much bird moves up on each jump
        self.jumpSpeed = 30
        # gravity
        self.drop = 1
        # is bird dead
        self.dead = False
        #
        self.sprite = 0
        # player's score
        self.counter = 0
        #
        self.offset = random.randint(-110, 110)
        #
        self.pipeSpeed = 2
        #
        self.countermuliply = 10



    def changeTheme(self, ThemeNum):
        # background image
        self.background = pygame.image.load("images/Theme" + str(ThemeNum) + "/bg.png").convert()
        # bird annimation (still image, flapping image, dead image)
        self.birdSprites = [pygame.image.load("images/Theme" + str(ThemeNum) + "/bird.2.png").convert_alpha(),
                            pygame.image.load("images/Theme" + str(ThemeNum) + "/bird.3.png").convert_alpha(),
                            pygame.image.load("images/Theme" + str(ThemeNum) + "/dead.png")]
        # bottom pipe                  
        self.wallUp = pygame.image.load("images/Theme" + str(ThemeNum) + "/bottom.png").convert_alpha()
        # top pipe
        self.wallDown = pygame.image.load("images/Theme" + str(ThemeNum) + "/top.png").convert_alpha()
        # message box
        self.msgbox = pygame.image.load("images/Theme" + str(ThemeNum) + "/msgbox.png").convert_alpha()


    
    def birdUpdate(self):
        if self.jump:
            # decrease bird speed
            self.jumpSpeed -= 1  
            # move bird up for the jump
            self.birdY -= self.jumpSpeed
            # set bird is jumping
            self.jump -= 1
        else:
            # move bird down 
            self.birdY += self.drop
            # increase drop ratio (gravity)
            self.drop += 0.1


        self.bird[1] = self.birdY

        # top pipe location and size
        upRect = pygame.Rect(self.pipe,
                             360 + self.distance - self.offset + 10,
                             self.wallUp.get_width() - 10,
                             self.wallUp.get_height())
        
        # bottom pipe location and size
        downRect = pygame.Rect(self.pipe,
                               0 - self.distance - self.offset - 10,
                               self.wallDown.get_width() - 10,
                               self.wallDown.get_height())


        #collision- the bird will be 'die' after colliding with the pipe
        if upRect.colliderect(self.bird):
            # the bird is dead by colliding with top pipe
            self.dead = True
           
        if downRect.colliderect(self.bird):
            # the bird is dead by colliding with bottom pipe
            self.dead = True

        if self.bird[1] > 700:
            self.dead = True

        if self.bird[1] < 10:
            self.dead = True
    

#      

            
    #defines the postion and propertoes of the pipe
    def updatePipes(self):
        self.pipe -= self.pipeSpeed
        # when a pipe moves out of screen
        if self.pipe < -80:
            # show a new pipe on right side
            self.pipe = 400
            # increase player's score depending on level 
            if not self.dead:
                self.counter += self.countermuliply
            # reset pipe offset position
            self.offset = random.randint(-110, 110)

    #run time tracks points
    def run(self):
        clock = pygame.time.Clock()
        #font of the text imported from sys system at the start of the game. 
        pygame.font.init()


   
        #(font style, font sizw )
        fontScore = pygame.font.SysFont("ariel", 50)
        fontMsgTitle = pygame.font.SysFont("arial",40)
        fontSmall1 = pygame.font.SysFont("arial",20)
        fontSmall2 = pygame.font.SysFont("arial",18)
        fontSmall3 = pygame.font.SysFont("arial",20)
        fontSmall4 = pygame.font.SysFont("arial",20)
        fontSmall5 = pygame.font.SysFont("arial",20)
        while True:
            clock.tick(60)

            #get a list of events that have occured 
            #since the last group illeration
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

                # this allows the player to "flap" the bird while key is pressed down
                if (event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN) and not self.dead:
                    self.jump = 17
                    #self.drop = 7
                    self.jumpSpeed = 10

 # This if block sets the varibles for the "easy" game level if 1 is pressed after the tutorial game or when the game is reset.
                if (self.dead and pygame.key.get_pressed()[pygame.K_1]==True):
                    self.bird[1] = 50
                    self.birdY = 50
                    self.dead = False
                    self.counter = 0
                    self.pipe = 400
                    self.distance = 170
                    self.offset = random.randint(-110, 110)
                    self.drop = 1
                    self.pipeSpeed = 1
                    # muliplies score depending on the level
                    self.countermuliply = 10
                    self.changeTheme(random.randint(1,3))

 # This if block sets the varibles for the "medium" game level if 2 is pressed after the tutorial game.
                if (self.dead and pygame.key.get_pressed()[pygame.K_2]==True):
                    self.bird[1] = 50
                    self.birdY = 50
                    self.dead = False
                    self.counter = 0
                    self.pipe = 400
                    self.distance = 160
                    self.offset = random.randint(-110, 110)
                    self.drop = 5
                    self.pipeSpeed = 2
                    # muliplies score depending on the level
                    self.countermuliply = 20
                    self.changeTheme(random.randint(1,3))

# This if block sets the varibles for the "Hard" game level if 3 is pressed after the tutorial game.
                if (self.dead and pygame.key.get_pressed()[pygame.K_3]==True):
                    self.bird[1] = 50
                    self.birdY = 50
                    self.dead = False
                    self.counter = 0
                    self.pipe = 400
                    self.distance = 150
                    self.offset = random.randint(-110, 110)
                    self.drop = 20
                    self.pipeSpeed = 4
                     # muliplies score depending on the level
                    self.countermuliply = 30
                    self.changeTheme(random.randint(1,3))
                    



#fills sreen backgouud
            self.screen.fill((255, 255, 255))
#blit fuction displays images on top of each other. self.distance - self.offset moves walls/pipes up and down
            self.screen.blit(self.background, (0, 0))
            self.screen.blit(self.wallUp,
                             (self.pipe, 360 + self.distance - self.offset))
            self.screen.blit(self.wallDown,
                             (self.pipe, 0 - self.distance - self.offset))

            # print player's score
            self.screen.blit(fontScore.render("Score: " + str(self.counter),
                                         -1, (50, 50, 50)), (125, 50))


            if self.dead:
                #sprite animeates image (bird.dead)
                self.sprite = 2
                #displays self.msgbox with Game over and players Final score. (displayed using fonts previously defined)
                self.screen.blit(self.msgbox, (70,200))
                self.screen.blit(fontMsgTitle.render("GAME OVER",
                                         -1, (200, 200, 0)), (82, 200))

                self.screen.blit(fontSmall1.render("Your Final Score: " + str(self.counter),
                                         -1, (0, 200, 200)), (82, 260))

                self.screen.blit(fontSmall2.render("Start a new game by pressing",
                                         -1, (0, 200, 200)), (82, 290))

                self.screen.blit(fontSmall3.render("1 for EASY",
                                         -1, (200, 200, 200)), (82, 320))
                self.screen.blit(fontSmall4.render("2 for MEDIUM",
                                         -1, (200, 200, 200)), (82, 350))
                self.screen.blit(fontSmall5.render("3 for HARD",
                                         -1, (200, 200, 200)), (82, 380))

            elif self.jump:
                self.sprite = 1
            self.screen.blit(self.birdSprites[self.sprite], (70, self.birdY))
            if not self.dead:
                self.sprite = 0
            self.updatePipes()
            self.birdUpdate()
            pygame.display.update()


            #if self.dead:




#            if self.dead:
#                pygame.time.delay(2000)

# Start the main program by executing run() of FlappyBird class
if __name__ == "__main__":
    FlappyBird().run()
